package redis.clients.johm;

public class InvalidFieldException extends RuntimeException {

    /**
     * 
     */
    private static final long serialVersionUID = -7953140268180103467L;

}
